</div> <!-- site content -->
<?php wp_footer() ?>
</body>
</html>